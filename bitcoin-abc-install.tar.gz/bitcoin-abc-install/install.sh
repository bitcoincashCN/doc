#!/bin/sh

ps -ef|grep bitcoind| grep -v grep | awk '{print $2}'|xargs kill -9

echo "==Start download bitcoin-abc-0.15.1-x86_64-linux-gnu.tar.gz"
wget https://download.bitcoinabc.org/0.15.1/linux/bitcoin-abc-0.15.1-x86_64-linux-gnu.tar.gz

echo
echo "==Start uncompress bitcoin-abc-0.15.1-x86_64-linux-gnu.tar.gz"
echo 

# uncompress bitcoin wallet
rm -rf bitcoin-abc-0.15.1
tar -zvxf bitcoin-abc-0.15.1-x86_64-linux-gnu.tar.gz


#create dir
rm -rf ~/.bitcoin/
mkdir ~/.bitcoin/

echo 
echo "==Add bitcoin.conf in ~/.bitcoin/ dir "
#add config file 
cp ./bitcoin.conf ~/.bitcoin/


#add crontab job for the bitcoin
crontab bcc.crontab

#check crontab job status
cronjobcnt=`crontab -l|grep bitcoin| wc -l`
if [ $cronjobcnt -eq 1 ]  
then
	echo "==Cron job installed OK"
else
	echo "==Cron job installed FAILED"
        exit 1
fi


retry=0
while true
do
	num=`ps -ef | grep bitcoind | grep -v grep | wc -l`
	if [ $num -eq 1 ]
	then
		echo "==bitcoin-abc start OK"
		break
        else
		echo "==Waiting for bitcoin-abc start..."
		sleep 10 
                retry=`expr $retry + 1` 
        fi
        if [ $retry -gt 8 ]
	then
		echo "==bitcoin-abc start FAILED"
		exit 1
        fi
done


echo 
echo "==Check the bitcoin-abc info ...."
sleep 5
~/bitcoin-abc-install/bitcoin-abc-0.15.1/bin/bitcoin-cli getinfo

